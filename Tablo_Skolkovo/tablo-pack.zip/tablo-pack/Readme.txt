1. tablo.js положить в корень папки "./SecurOS/node.js/"
2. Папку node_modules скопировать в "./SecurOS/node.js/" или если есть интернет установить iconv-lite командной "npm i iconv-lite"
3 .Пример скрипта в файле securos_script.js
4. Допустимые эффекты можно так же подглядеть в tablo.js