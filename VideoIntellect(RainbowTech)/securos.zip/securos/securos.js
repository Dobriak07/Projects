/**
 * 
 */

const makeMsgKey = function (srcType, srcId, action) {
    return `${srcType}|${srcId}|${action}`;
}

class CoreApiQueries {
    constructor(core) {
        this._core = core;
        this._queries = new Array();

        this._core.apiResponseReceived.connect((message) => {
            let callback = this._queries.shift();
            if ('error' in message)
                callback.reject(message.error);
            else
                callback.resolve(message.response);
        });
    }

    sendRequest(request) {
        return new Promise((resolve, reject) => {
            this._queries.push({ resolve, reject });
            this._core.sendApiRequest({ request });
        });
    }
}

class CoreObject {
    constructor(core, data) {
        this._core = core;
        Object.assign(this, data);
    }

    getChildsIds(childType) {
        return this._core.getObjectChildsIds(this.type, this.id, childType);
    }

    getParentId(parentType) {
        if (parentType)
            return this._core.getObjectParentId(this.type, this.id, parentType);
        else
            return Promise.resolve(this.parentId);
    }
}


/**
 * SecurOS public interface
 */
class Core {
    constructor(transport, qwebchannel) {
        // private properties    
        this._eventSubscriptions = new Map();
        this._reactSubscriptions = new Map();
        this._objectConfigSubscriptions = new Map();
        this._transport = transport;
        this._qwebchannel = qwebchannel;
        this._apiQueries = new CoreApiQueries(this._qwebchannel.objects.core);

        // public properties
        this.selfId = this._qwebchannel.objects.core.selfId;
        this.selfType = this._qwebchannel.objects.core.selfType;

        // connect to signals
        this._qwebchannel.objects.core.eventReceived.connect((sourceType, sourceId, action, params) => {
            const keys = [
                makeMsgKey(sourceType, sourceId, action),
                makeMsgKey(sourceType, '*', action),
                makeMsgKey(sourceType, sourceId, '*'),
                makeMsgKey(sourceType, '*', '*')
            ];
            for (let key of keys) {
                if (this._eventSubscriptions.has(key)) {
                    const callback = this._eventSubscriptions.get(key);
                    callback({ sourceType, sourceId, action, params });
                }
            }
        });

        this._qwebchannel.objects.core.reactReceived.connect((sourceType, sourceId, action, params) => {
            if (this._reactSubscriptions.has(action)) {
                const callback = this._reactSubscriptions.get(action);
                callback({ sourceType, sourceId, action, params });
            }
        });

        this._qwebchannel.objects.core.objectChanged.connect((sourceType, sourceId, action, params) => {
            const keys = [sourceType, '*'];
            for (let key of keys) {
                if (this._objectConfigSubscriptions.has(key)) {
                    const callback = this._objectConfigSubscriptions.get(key);
                    callback({ sourceType, sourceId, action, params });
                }
            }
        });
    }

    disconnect() {
        this._transport.close();
    }

    sendEvent(sourceType, sourceId, action, params) {
        const core = this._qwebchannel.objects.core;
        core.sendEvent(sourceType, sourceId, action, params || {});
    }

    doReact(sourceType, sourceId, action, params) {
        const core = this._qwebchannel.objects.core;
        core.doReact(sourceType, sourceId, action, params || {});
    }

    registerEventHandler(sourceType, sourceId, action, callback) {
        const key = makeMsgKey(sourceType, sourceId, action);
        this._eventSubscriptions.set(key, callback);
        this._qwebchannel.objects.core.subscribeToEvent(sourceType, sourceId, action);

        let self = this;
        let subscription = {
            unregister: function () {
                self._eventSubscriptions.delete(key);
                self._qwebchannel.objects.core.unsubscribeFromEvent(sourceType, sourceId, action);
            }
        };

        return subscription;
    }

    registerReact(action, callback) {
        this._reactSubscriptions.set(action, callback);
        this._qwebchannel.objects.core.subscribeToReact(action);

        let self = this;
        let subscription = {
            unregister: function () {
                self._reactSubscriptions.delete(action);
                self._qwebchannel.objects.core.unsubscribeFromReact(action);
            }
        };

        return subscription;
    }

    registerObjectHandler(type, callback) {
        this._objectConfigSubscriptions.set(type, callback);
        this._qwebchannel.objects.core.subscribeToObject(type);

        let self = this;
        let subscription = {
            unregister: function () {
                self._objectConfigSubscriptions.delete(type);
                self._qwebchannel.objects.core.unsubscribeFromObject(type);
            }
        };

        return subscription;
    }

    getObjectsIds(type) {
        return this._apiQueries.sendRequest({
            method: 'getObjectsIdsByType',
            params: { type }
        });
    }

    getObjectChildsIds(type, id, childType) {
        return this._apiQueries.sendRequest({
            method: 'getChildsIdsByType',
            params: { type, id, childType }
        });
    }

    getObjectParentId(type, id, parentType) {
        parentType = parentType || '';
        return this._apiQueries.sendRequest({
            method: 'getParentIdByType',
            params: { type, id, parentType }
        });
    }

    getObject(type, id) {
        return this._apiQueries.sendRequest({
            method: 'getObjectData',
            params: { type, id }
        }).then((data) => {
            return data && new CoreObject(this, data);
        });
    }
};


async function createTransport() {
    const transport = require('./internal/transport.js');
    return new Promise(transport.initialize);
}


async function initQWebChannel(transport) {
    return new Promise((resolve) => {
        const { QWebChannel } = require('./internal/qwebchannel.js');
        new QWebChannel(transport, (channel) => { resolve({ channel, transport }); });
    });
}


module.exports = {
    connect: function (resolve) {
        let connectAllowed = true;
        return function (resolve) {
            if (connectAllowed) {
                connectAllowed = false;
                createTransport()
                    .then(initQWebChannel, () => { connectAllowed = true; })
                    .then((connection) => { resolve(new Core(connection.transport, connection.channel)); })
            } else {
                throw new Error("Multiple connections is not supported");
            }
        };
    }(),
    ObjectEvent: {
        CREATED: "CREATED",
        UPDATED: "UPDATED",
        DELETED: "DELETED"
    },
    MediaClientKey: {
        ARM: "ARM",
        DISARM: "DISARM",
        REC: "REC",
        REC_STOP: "REC_STOP",
        LEFT: "LEFT",
        RIGHT: "RIGHT",
        UP: "UP",
        DOWN: "DOWN",
        NEXT_PAGE: "NEXT_PAGE",
        PREV_PAGE: "PREV_PAGE",
        FF: "FF",
        REW: "REW",
        PLAY: "PLAY",
        STOP: "STOP",
        MODE_ARCH: "MODE_ARCH",
        MODE_VIDEO: "MODE_VIDEO"
    }
};
