const net = require('net');
const process = require('process');

class Logger {
    constructor() {
        this.enabled = false;

        const debugLogPath = 'SECUROS_NODEJS_DEBUG_LOG_FILE';
        if (debugLogPath in process.env) {
            const logFile = process.env[debugLogPath];
            this.stream = require('fs').createWriteStream(logFile, { flags: 'a' });
            this.stream.on('ready', () => { this.enabled = true; });
        }
    }

    write(data, type) {
        if (this.enabled) {
            const t = new Date(Date.now());
            this.stream.write("[" + type + ":" + t.toISOString() + "]\n");
            this.stream.write(data + "\n\n");
        }
    }
};

class Transport {
    constructor(socket) {
        this.log = new Logger();
        this.socket = socket;
        this.inMsgBuf = "";
        this.onmessage = null;

        socket.on('data', (ibuf) => {
            this.log.write(ibuf, "IN");
            let start = 0;
            let end = 0;

            while (true) {
                if (start >= ibuf.length)
                    return;

                end = ibuf.indexOf(0, start);
                if (end < 0) {
                    this.inMsgBuf += ibuf.slice(start, ibuf.length).toString('utf8');
                    return;
                }

                this.inMsgBuf += ibuf.slice(start, end).toString('utf8');
                if (this.inMsgBuf.length > 0 && this.onmessage) {
                    const data = JSON.parse(this.inMsgBuf);
                    this.onmessage({ data });
                }

                this.inMsgBuf = "";
                start = end + 1;
            }
        });
    }

    send(msg) {
        if (typeof msg !== 'string')
            msg = JSON.stringify(msg);

        let buf = Buffer.from(msg, 'utf8');
        let delimiter = Buffer.alloc(1, 0);
        buf = Buffer.concat([buf, delimiter], buf.length + delimiter.length);

        this.log.write(buf, "OUT");
        this.socket.write(buf);
    }

    close() {
        this.socket.destroy();
    }
};


function initialize(onReady, onError) {
    const serverName = process.env['SECUROS_NODEJS_API_SERVER'];
    const socket = new net.createConnection(serverName);

    socket.on('connect', () => {
        onReady(new Transport(socket));
    });

    socket.on('error', () => {
        console.error('Cannot connect to SecurOS core!');
        if (onError)
            onError();
    });
};


module.exports = {
    initialize: initialize
};
